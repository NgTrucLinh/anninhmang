using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SchnorrAspNet.Services;
using System.Text;
using System.Text.Json;

namespace SchnorrAspNet.Pages;

[RequestSizeLimit(50 * 1024 * 1024)]
public class IndexModel : PageModel
{
    private const string SessionKey = "schnorrModel";

    [BindProperty] public string PHex { get; set; } = "";
    [BindProperty] public string QHex { get; set; } = "";
    [BindProperty] public string GHex { get; set; } = "";
    [BindProperty] public string PrivateKey { get; set; } = "";
    [BindProperty] public string Message { get; set; } = "";
    [BindProperty] public IFormFile? FileTxt { get; set; }
    [BindProperty] public string VerifyMessage { get; set; } = "";
    [BindProperty] public IFormFile? VerifyFileTxt { get; set; }
    [BindProperty] public string SigEInput { get; set; } = "";
    [BindProperty] public string SigSInput { get; set; } = "";

    public string PublicKey { get; private set; } = "";
    public string? Error { get; private set; }
    public string? SuccessMsg { get; private set; }
    public string? SigE { get; private set; }
    public string? SigS { get; private set; }
    public string SignedMessage { get; private set; } = "";
    public bool? VerifyResult { get; private set; }
    public bool HasKeys => !string.IsNullOrWhiteSpace(PublicKey);

    public void OnGet() => PushKeysToUi(LoadModel());

    public IActionResult OnPostGenerateKeys()
    {
        try
        {
            var model = new SchnorrDigitalSignatureModel();
            model.GenerateKeys();
            SaveModel(model);
            PushKeysToUi(model);
            SuccessMsg = "Tạo bộ khóa ngẫu nhiên thành công!";
        }
        catch (Exception ex)
        {
            Error = "Sinh khóa thất bại: " + ex.Message;
        }

        return Page();
    }

    public IActionResult OnPostSetKeys()
    {
        if (string.IsNullOrWhiteSpace(PHex) ||
            string.IsNullOrWhiteSpace(QHex) ||
            string.IsNullOrWhiteSpace(GHex) ||
            string.IsNullOrWhiteSpace(PrivateKey))
        {
            Error = "Vui lòng nhập đầy đủ các tham số p, q, g và khóa bí mật x.";
            return Page();
        }

        try
        {
            var model = new SchnorrDigitalSignatureModel();
            model.SetKeysManual(PHex, QHex, GHex, PrivateKey);
            SaveModel(model);
            PushKeysToUi(model);
            SuccessMsg = "Cấu hình khóa thủ công thành công!";
        }
        catch (FormatException)
        {
            Error = "Tham số phải là chuỗi HEX hợp lệ (0-9, A-F).";
        }
        catch (ArgumentException ex)
        {
            Error = "Tham số không hợp lệ: " + ex.Message;
        }

        return Page();
    }

    public async Task<IActionResult> OnPostSignAsync()
    {
        var model = LoadModel();
        PushKeysToUi(model);

        if (model is null || !model.HasPrivateKey)
        {
            Error = "Chưa có thông tin khóa. Vui lòng tạo hoặc nhập khóa trước.";
            return Page();
        }

        var msg = await ReadMessageAsync(FileTxt, Message, "txt");
        if (msg is null)
        {
            return Page();
        }

        try
        {
            var (e, s) = model.Sign(msg);
            SigE = e.ToString("X");
            SigS = s.ToString("X");
            SignedMessage = msg;
            Message = msg;
            SuccessMsg = "Ký số thành công!";
        }
        catch (Exception ex)
        {
            Error = "Lỗi trong quá trình ký: " + ex.Message;
            Message = msg;
            SignedMessage = msg;
        }

        return Page();
    }

    public async Task<IActionResult> OnPostVerifyAsync()
    {
        var model = LoadModel();
        PushKeysToUi(model);

        if (model is null || !model.HasPublicKey)
        {
            Error = "Chưa thiết lập khóa công khai. Vui lòng tạo hoặc nhập khóa trước.";
            return Page();
        }

        var msg = await ReadMessageAsync(VerifyFileTxt, VerifyMessage, "txt");
        VerifyMessage = msg ?? VerifyMessage;

        if (msg is null)
        {
            return Page();
        }

        if (string.IsNullOrWhiteSpace(SigEInput) || string.IsNullOrWhiteSpace(SigSInput))
        {
            Error = "Vui lòng nhập đầy đủ cặp chữ ký (e, s).";
            return Page();
        }

        try
        {
            VerifyResult = model.Verify(msg, SigEInput, SigSInput);
            if (VerifyResult.Value)
            {
                SuccessMsg = "Xác minh THÀNH CÔNG, tài liệu toàn vẹn nguyên bản.";
            }
            else
            {
                Error = "Xác minh THẤT BẠI, chữ ký không khớp hoặc nội dung bị thay đổi.";
            }
        }
        catch (FormatException)
        {
            Error = "Định dạng lỗi: cặp chữ ký (e, s) phải là chuỗi HEX hợp lệ.";
        }

        return Page();
    }

    public IActionResult OnPostReset()
    {
        HttpContext.Session.Remove(SessionKey);
        SuccessMsg = "Đã đặt lại toàn bộ hệ thống. Vui lòng tạo khóa mới.";
        return Page();
    }

    private async Task<string?> ReadMessageAsync(IFormFile? file, string text, string allowedExt)
    {
        if (file is { Length: > 0 })
        {
            var fileName = Path.GetFileName(file.FileName);
            if (!fileName.EndsWith("." + allowedExt, StringComparison.OrdinalIgnoreCase))
            {
                Error = $"Chỉ chấp nhận file .{allowedExt}. File bạn chọn: {fileName}";
                return null;
            }

            if (file.Length > 10 * 1024 * 1024)
            {
                Error = "File vượt quá giới hạn 10 MB.";
                return null;
            }

            using var reader = new StreamReader(file.OpenReadStream(), Encoding.UTF8);
            text = await reader.ReadToEndAsync();
        }

        if (string.IsNullOrWhiteSpace(text))
        {
            Error = $"Vui lòng cung cấp nội dung văn bản hoặc tải lên file .{allowedExt}.";
            return null;
        }

        return text;
    }

    private SchnorrDigitalSignatureModel? LoadModel()
    {
        var json = HttpContext.Session.GetString(SessionKey);
        if (string.IsNullOrWhiteSpace(json))
        {
            return null;
        }

        var state = JsonSerializer.Deserialize<SchnorrState>(json);
        return state is null ? null : SchnorrDigitalSignatureModel.FromState(state);
    }

    private void SaveModel(SchnorrDigitalSignatureModel model)
    {
        HttpContext.Session.SetString(SessionKey, JsonSerializer.Serialize(model.ToState()));
    }

    private void PushKeysToUi(SchnorrDigitalSignatureModel? model)
    {
        if (model is null)
        {
            return;
        }

        PHex = model.PHex;
        QHex = model.QHex;
        GHex = model.GHex;
        PrivateKey = model.PrivateKeyHex;
        PublicKey = model.PublicKeyHex;
    }
}
