﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SchnorrAspNet.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

