using System.Globalization;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace SchnorrAspNet.Services;

public sealed class SchnorrDigitalSignatureModel
{
    private BigInteger? _p;
    private BigInteger? _q;
    private BigInteger? _g;
    private BigInteger? _privateKey;
    private BigInteger? _publicKey;

    public string PHex => ToHex(_p);
    public string QHex => ToHex(_q);
    public string GHex => ToHex(_g);
    public string PrivateKeyHex => ToHex(_privateKey);
    public string PublicKeyHex => ToHex(_publicKey);
    public bool HasKeys => _privateKey.HasValue && _publicKey.HasValue;
    public bool HasPrivateKey => _privateKey.HasValue;
    public bool HasPublicKey => _publicKey.HasValue;

    public static SchnorrDigitalSignatureModel FromState(SchnorrState state)
    {
        var model = new SchnorrDigitalSignatureModel();
        if (!string.IsNullOrWhiteSpace(state.PHex)) model._p = FromHex(state.PHex);
        if (!string.IsNullOrWhiteSpace(state.QHex)) model._q = FromHex(state.QHex);
        if (!string.IsNullOrWhiteSpace(state.GHex)) model._g = FromHex(state.GHex);
        if (!string.IsNullOrWhiteSpace(state.PrivateKeyHex)) model._privateKey = FromHex(state.PrivateKeyHex);
        if (!string.IsNullOrWhiteSpace(state.PublicKeyHex)) model._publicKey = FromHex(state.PublicKeyHex);
        return model;
    }

    public SchnorrState ToState() => new(PHex, QHex, GHex, PrivateKeyHex, PublicKeyHex);

    public void GenerateKeys()
    {
        _q = GeneratePrime(160);

        BigInteger k;
        var attempt = 0;
        do
        {
            if (++attempt > 10_000)
            {
                throw new InvalidOperationException("Không thể sinh tham số p sau 10.000 lần thử.");
            }

            k = RandomBigInteger(352);
            k |= BigInteger.One << 351;
            _p = k * _q.Value + BigInteger.One;
        } while (!IsProbablePrime(_p.Value, 80));

        var exp = (_p.Value - BigInteger.One) / _q.Value;
        attempt = 0;
        do
        {
            if (++attempt > 10_000)
            {
                throw new InvalidOperationException("Không thể sinh bộ phát sinh g sau 10.000 lần thử.");
            }

            var h = RandomInRange(new BigInteger(2), _p.Value - BigInteger.One);
            _g = BigInteger.ModPow(h, exp, _p.Value);
        } while (_g.Value == BigInteger.One);

        if (BigInteger.ModPow(_g.Value, _q.Value, _p.Value) != BigInteger.One)
        {
            throw new InvalidOperationException("g sinh ra không có bậc q, hãy thử lại.");
        }

        do
        {
            _privateKey = RandomBigInteger(_q.Value.GetBitLength());
        } while (_privateKey.Value <= BigInteger.One || _privateKey.Value >= _q.Value);

        _publicKey = BigInteger.ModPow(_g.Value, Mod(-_privateKey.Value, _q.Value), _p.Value);
    }

    public void SetKeysManual(string pHex, string qHex, string gHex, string xHex)
    {
        var p = FromHex(pHex);
        var q = FromHex(qHex);
        var g = FromHex(gHex);
        var x = FromHex(xHex);

        if (x <= BigInteger.One || x >= q)
        {
            throw new ArgumentException("Khóa bí mật x phải thỏa: 1 < x < q.");
        }

        if (g <= BigInteger.One || g >= p)
        {
            throw new ArgumentException("Bộ sinh g phải thỏa: 1 < g < p.");
        }

        if (BigInteger.ModPow(g, q, p) != BigInteger.One)
        {
            throw new ArgumentException("g không có bậc q mod p, tham số nhóm không hợp lệ.");
        }

        _p = p;
        _q = q;
        _g = g;
        _privateKey = x;
        _publicKey = BigInteger.ModPow(g, Mod(-x, q), p);
    }

    public (BigInteger E, BigInteger S) Sign(string message)
    {
        EnsurePrivateReady();

        BigInteger k;
        do
        {
            k = RandomBigInteger(_q!.Value.GetBitLength());
        } while (k <= BigInteger.One || k >= _q.Value);

        var r = BigInteger.ModPow(_g!.Value, k, _p!.Value);
        var e = Hash(message, r, _q.Value);
        var s = (k + _privateKey!.Value * e) % _q.Value;
        return (e, s);
    }

    public bool Verify(string message, string eHex, string sHex)
    {
        EnsurePublicReady();

        var e = FromHex(eHex);
        var s = FromHex(sHex);

        if (e <= BigInteger.Zero || e >= _q!.Value)
        {
            return false;
        }

        if (s <= BigInteger.Zero || s >= _q.Value)
        {
            return false;
        }

        var gs = BigInteger.ModPow(_g!.Value, s, _p!.Value);
        var ye = BigInteger.ModPow(_publicKey!.Value, e, _p.Value);
        var rv = gs * ye % _p.Value;
        var ev = Hash(message, rv, _q.Value);
        return ev == e;
    }

    private void EnsurePrivateReady()
    {
        if (!_p.HasValue || !_q.HasValue || !_g.HasValue || !_privateKey.HasValue)
        {
            throw new InvalidOperationException("Chưa khởi tạo tham số khóa.");
        }
    }

    private void EnsurePublicReady()
    {
        if (!_p.HasValue || !_q.HasValue || !_g.HasValue || !_publicKey.HasValue)
        {
            throw new InvalidOperationException("Chưa khởi tạo tham số khóa công khai.");
        }
    }

    private static BigInteger Hash(string message, BigInteger r, BigInteger q)
    {
        using var sha = SHA256.Create();
        var msgBytes = Encoding.UTF8.GetBytes(message);
        var rBytes = r.ToByteArray(isUnsigned: true, isBigEndian: true);
        var bytes = new byte[msgBytes.Length + rBytes.Length];
        Buffer.BlockCopy(msgBytes, 0, bytes, 0, msgBytes.Length);
        Buffer.BlockCopy(rBytes, 0, bytes, msgBytes.Length, rBytes.Length);
        var digest = sha.ComputeHash(bytes);
        return new BigInteger(digest, isUnsigned: true, isBigEndian: true) % q;
    }

    private static BigInteger GeneratePrime(int bits)
    {
        while (true)
        {
            var candidate = RandomBigInteger(bits);
            candidate |= BigInteger.One << (bits - 1);
            candidate |= BigInteger.One;
            if (IsProbablePrime(candidate, 80))
            {
                return candidate;
            }
        }
    }

    private static bool IsProbablePrime(BigInteger value, int witnesses)
    {
        if (value < 2) return false;
        if (value == 2 || value == 3) return true;
        if (value.IsEven) return false;

        var d = value - 1;
        var s = 0;
        while (d.IsEven)
        {
            d /= 2;
            s++;
        }

        for (var i = 0; i < witnesses; i++)
        {
            var a = RandomInRange(new BigInteger(2), value - 2);
            var x = BigInteger.ModPow(a, d, value);
            if (x == 1 || x == value - 1) continue;

            var composite = true;
            for (var r = 1; r < s; r++)
            {
                x = BigInteger.ModPow(x, 2, value);
                if (x == value - 1)
                {
                    composite = false;
                    break;
                }
            }

            if (composite)
            {
                return false;
            }
        }

        return true;
    }

    private static BigInteger RandomBigInteger(long bits)
    {
        var bytes = new byte[(bits + 7) / 8];
        RandomNumberGenerator.Fill(bytes);
        var excessBits = bytes.Length * 8 - bits;
        if (excessBits > 0)
        {
            bytes[0] &= (byte)(0xff >> (int)excessBits);
        }

        return new BigInteger(bytes, isUnsigned: true, isBigEndian: true);
    }

    private static BigInteger RandomInRange(BigInteger minInclusive, BigInteger maxInclusive)
    {
        var range = maxInclusive - minInclusive + 1;
        var bits = range.GetBitLength();
        BigInteger value;
        do
        {
            value = RandomBigInteger(bits);
        } while (value >= range);

        return minInclusive + value;
    }

    private static BigInteger FromHex(string hex)
    {
        var clean = (hex ?? string.Empty).Trim();
        if (clean.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
        {
            clean = clean[2..];
        }

        if (clean.Length == 0 || clean.Any(c => !Uri.IsHexDigit(c)))
        {
            throw new FormatException("Giá trị phải là chuỗi HEX hợp lệ.");
        }

        if (clean.Length % 2 == 1)
        {
            clean = "0" + clean;
        }

        var bytes = Convert.FromHexString(clean);
        return new BigInteger(bytes, isUnsigned: true, isBigEndian: true);
    }

    private static string ToHex(BigInteger? value)
    {
        if (!value.HasValue)
        {
            return string.Empty;
        }

        return value.Value.ToString("X", CultureInfo.InvariantCulture).TrimStart('0') is { Length: > 0 } hex
            ? hex
            : "0";
    }

    private static BigInteger Mod(BigInteger value, BigInteger modulus)
    {
        var result = value % modulus;
        return result < 0 ? result + modulus : result;
    }
}

public sealed record SchnorrState(
    string PHex,
    string QHex,
    string GHex,
    string PrivateKeyHex,
    string PublicKeyHex);
