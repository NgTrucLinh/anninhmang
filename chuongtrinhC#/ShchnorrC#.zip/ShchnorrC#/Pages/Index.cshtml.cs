using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SchnorrAspNet.Services;
using System.Text;
using System.Text.Json;

 namespace ShnorrbyTQK.Pages;

[RequestSizeLimit(50 * 1024 * 1024)]
public class IndexModel : PageModel
{
    private const string SessionKey = "schnorrModel";

    [BindProperty] public string PHex { get; set; } = "";
    [BindProperty] public string QHex { get; set; } = "";
    [BindProperty] public string GHex { get; set; } = "";
    [BindProperty] public string PrivateKey { get; set; } = "";
    [BindProperty] public string Message { get; set; } = "";
    [BindProperty] public IFormFile? FileTxt { get; set; }
    [BindProperty] public string VerifyMessage { get; set; } = "";
    [BindProperty] public IFormFile? VerifyFileTxt { get; set; }
    [BindProperty] public string SigEInput { get; set; } = "";
    [BindProperty] public string SigSInput { get; set; } = "";

    public string PublicKey { get; set; } = "";
    public string? Error { get; set; }
    public string? SuccessMsg { get; set; }
    public string? SigE { get; set; }
    public string? SigS { get; set; }
    public bool? VerifyResult { get; set; }

    public void OnGet()
    {
        PushKeysToUi(LoadModel());
    }

    public IActionResult OnPostGenerateKeys()
    {
        try
        {
            var model = new SchnorrDigitalSignatureModel();
            model.GenerateKeys();
            SaveModel(model);
            PushKeysToUi(model);
            SuccessMsg = "Tạo bộ khóa thành công!";
        }
        catch (Exception ex)
        {
            Error = "Sinh khóa thất bại: " + ex.Message;
        }

        return Page();
    }

    public IActionResult OnPostSetKeys()
    {
        try
        {
            var model = new SchnorrDigitalSignatureModel();
            model.SetKeysManual(PHex, QHex, GHex, PrivateKey);
            SaveModel(model);
            PushKeysToUi(model);
            SuccessMsg = "Áp dụng khóa thủ công thành công!";
        }
        catch (Exception ex)
        {
            Error = "Lỗi nhập khóa: " + ex.Message;
        }

        return Page();
    }

    public async Task<IActionResult> OnPostSignAsync()
    {
        var model = LoadModel();
        PushKeysToUi(model);

        if (model == null || !model.HasPrivateKey)
        {
            Error = "Chưa có khóa. Vui lòng sinh khóa trước.";
            return Page();
        }

        var msg = await ReadMessageAsync(FileTxt, Message);

        if (msg == null)
            return Page();

        try
        {
            var (e, s) = model.Sign(msg);
            SigE = e.ToString("X");
            SigS = s.ToString("X");
            Message = msg;
            SuccessMsg = "Ký số thành công!";
        }
        catch (Exception ex)
        {
            Error = "Lỗi ký số: " + ex.Message;
        }

        return Page();
    }

    public async Task<IActionResult> OnPostVerifyAsync()
    {
        var model = LoadModel();
        PushKeysToUi(model);

        if (model == null || !model.HasPublicKey)
        {
            Error = "Chưa có khóa công khai. Vui lòng sinh khóa trước.";
            return Page();
        }

        var msg = await ReadMessageAsync(VerifyFileTxt, VerifyMessage);

        if (msg == null)
            return Page();

        try
        {
            VerifyResult = model.Verify(msg, SigEInput, SigSInput);
            VerifyMessage = msg;

            if (VerifyResult == true)
                SuccessMsg = "Xác minh thành công. Chữ ký hợp lệ.";
            else
                Error = "Xác minh thất bại. Chữ ký không hợp lệ.";
        }
        catch (Exception ex)
        {
            Error = "Lỗi xác minh: " + ex.Message;
        }

        return Page();
    }

    public IActionResult OnPostReset()
    {
        HttpContext.Session.Remove(SessionKey);
        SuccessMsg = "Đã đặt lại hệ thống.";
        return Page();
    }

    private async Task<string?> ReadMessageAsync(IFormFile? file, string text)
    {
        if (file != null && file.Length > 0)
        {
            if (!file.FileName.EndsWith(".txt"))
            {
                Error = "Chỉ chấp nhận file .txt";
                return null;
            }

            using var reader = new StreamReader(file.OpenReadStream(), Encoding.UTF8);
            text = await reader.ReadToEndAsync();
        }

        if (string.IsNullOrWhiteSpace(text))
        {
            Error = "Vui lòng nhập nội dung hoặc tải file .txt.";
            return null;
        }

        return text;
    }

    private SchnorrDigitalSignatureModel? LoadModel()
    {
        var json = HttpContext.Session.GetString(SessionKey);
        if (string.IsNullOrWhiteSpace(json)) return null;

        var state = JsonSerializer.Deserialize<SchnorrState>(json);
        return state == null ? null : SchnorrDigitalSignatureModel.FromState(state);
    }

    private void SaveModel(SchnorrDigitalSignatureModel model)
    {
        HttpContext.Session.SetString(SessionKey, JsonSerializer.Serialize(model.ToState()));
    }

    private void PushKeysToUi(SchnorrDigitalSignatureModel? model)
    {
        if (model == null) return;

        PHex = model.PHex;
        QHex = model.QHex;
        GHex = model.GHex;
        PrivateKey = model.PrivateKeyHex;
        PublicKey = model.PublicKeyHex;
    }
}