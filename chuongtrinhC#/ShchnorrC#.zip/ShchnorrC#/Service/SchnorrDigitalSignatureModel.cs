﻿using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace SchnorrAspNet.Services;

public class SchnorrState
{
    public string PHex { get; set; } = "";
    public string QHex { get; set; } = "";
    public string GHex { get; set; } = "";
    public string PrivateKeyHex { get; set; } = "";
    public string PublicKeyHex { get; set; } = "";
}

public class SchnorrDigitalSignatureModel
{
    private BigInteger P, Q, G, X, Y;

    public string PHex => P.ToString("X");
    public string QHex => Q.ToString("X");
    public string GHex => G.ToString("X");
    public string PrivateKeyHex => X.ToString("X");
    public string PublicKeyHex => Y.ToString("X");

    public bool HasPrivateKey => X > 0;
    public bool HasPublicKey => Y > 0;

    private static BigInteger GeneratePFromQ(BigInteger q, int pBits)
    {
        while (true)
        {
            var k = RandomBigInteger(
                BigInteger.One << (pBits - 161),
                BigInteger.One << (pBits - 160)
            );

            var p = k * q + 1;

            if (IsProbablePrime(p, 20))
                return p;
        }
    }

    private static BigInteger GenerateGenerator(BigInteger p, BigInteger q)
    {
        while (true)
        {
            var h = RandomBigInteger(2, p - 2);
            var g = BigInteger.ModPow(h, (p - 1) / q, p);

            if (g > 1)
                return g;
        }
    }

    private static BigInteger GeneratePrime(int bits)
    {
        while (true)
        {
            var n = RandomBigInteger(
                BigInteger.One << (bits - 1),
                BigInteger.One << bits
            );

            if (n.IsEven)
                n += 1;

            if (IsProbablePrime(n, 20))
                return n;
        }
    }

    private static bool IsProbablePrime(BigInteger n, int rounds)
    {
        if (n < 2) return false;
        if (n == 2 || n == 3) return true;
        if (n.IsEven) return false;

        BigInteger d = n - 1;
        int s = 0;

        while (d.IsEven)
        {
            d /= 2;
            s++;
        }

        for (int i = 0; i < rounds; i++)
        {
            BigInteger a = RandomBigInteger(2, n - 2);
            BigInteger x = BigInteger.ModPow(a, d, n);

            if (x == 1 || x == n - 1)
                continue;

            bool passed = false;

            for (int r = 1; r < s; r++)
            {
                x = BigInteger.ModPow(x, 2, n);

                if (x == n - 1)
                {
                    passed = true;
                    break;
                }
            }

            if (!passed)
                return false;
        }

        return true;
    }
    public void GenerateKeys()
    {
        Q = GeneratePrime(160);
        P = GeneratePFromQ(Q, 512);
        G = GenerateGenerator(P, Q);

        X = RandomBigInteger(2, Q - 1);
        Y = BigInteger.ModPow(G, X, P);
    }

    public void SetKeysManual(string pHex, string qHex, string gHex, string xHex)
    {
        P = ParseHex(pHex);
        Q = ParseHex(qHex);
        G = ParseHex(gHex);
        X = ParseHex(xHex);

        if (P <= 0 || Q <= 0 || G <= 0 || X <= 0)
            throw new ArgumentException("Các tham số phải lớn hơn 0.");

        Y = BigInteger.ModPow(G, X, P);
    }

    public (BigInteger e, BigInteger s) Sign(string message)
    {
        var r = RandomBigInteger(2, Q - 1);
        var a = BigInteger.ModPow(G, r, P);

        var e = HashToBigInteger(message + a.ToString("X")) % Q;
        var s = (r + X * e) % Q;

        return (e, s);
    }

    public bool Verify(string message, string eHex, string sHex)
    {
        var e = ParseHex(eHex);
        var s = ParseHex(sHex);

        var gs = BigInteger.ModPow(G, s, P);
        var ye = BigInteger.ModPow(Y, e, P);
        var yeInv = ModInverse(ye, P);

        var a = (gs * yeInv) % P;
        var eCheck = HashToBigInteger(message + a.ToString("X")) % Q;

        return eCheck == e;
    }

    public SchnorrState ToState()
    {
        return new SchnorrState
        {
            PHex = PHex,
            QHex = QHex,
            GHex = GHex,
            PrivateKeyHex = PrivateKeyHex,
            PublicKeyHex = PublicKeyHex
        };
    }

    public static SchnorrDigitalSignatureModel FromState(SchnorrState state)
    {
        var model = new SchnorrDigitalSignatureModel
        {
            P = ParseHex(state.PHex),
            Q = ParseHex(state.QHex),
            G = ParseHex(state.GHex),
            X = ParseHex(state.PrivateKeyHex),
            Y = ParseHex(state.PublicKeyHex)
        };

        return model;
    }

    private static BigInteger ParseHex(string hex)
    {
        if (string.IsNullOrWhiteSpace(hex))
            return BigInteger.Zero;

        hex = hex.Replace(" ", "").Trim();

        return BigInteger.Parse("0" + hex, System.Globalization.NumberStyles.HexNumber);
    }

    private static BigInteger HashToBigInteger(string input)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        return new BigInteger(bytes, isUnsigned: true, isBigEndian: true);
    }

    private static BigInteger RandomBigInteger(BigInteger min, BigInteger max)
    {
        var bytes = max.ToByteArray(isUnsigned: true, isBigEndian: true);
        BigInteger result;

        do
        {
            RandomNumberGenerator.Fill(bytes);
            result = new BigInteger(bytes, isUnsigned: true, isBigEndian: true);
        }
        while (result < min || result >= max);

        return result;
    }

    private static BigInteger ModInverse(BigInteger a, BigInteger m)
    {
        BigInteger m0 = m, x0 = 0, x1 = 1;

        if (m == 1) return 0;

        while (a > 1)
        {
            var q = a / m;
            var t = m;

            m = a % m;
            a = t;
            t = x0;

            x0 = x1 - q * x0;
            x1 = t;
        }

        return x1 < 0 ? x1 + m0 : x1;
    }
}